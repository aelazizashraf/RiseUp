import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfficeHoursHelpComponent } from './office-hours-help.component';

describe('OfficeHoursHelpComponent', () => {
  let component: OfficeHoursHelpComponent;
  let fixture: ComponentFixture<OfficeHoursHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficeHoursHelpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficeHoursHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
