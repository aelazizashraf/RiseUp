import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-office-hours-help',
  templateUrl: './office-hours-help.component.html',
  styleUrls: ['./office-hours-help.component.css']
})
export class OfficeHoursHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
