import { Component, OnInit } from '@angular/core';
import { DatabaseService } from '../database.service';

@Component({
    selector: 'app-home',
    templateUrl: './experts.component.html'
})
export class ExpertsComponent implements OnInit {

    experts;
    loggedIn;

    constructor(private databaseService: DatabaseService) {

    }

    ngOnInit() {
        this.databaseService.getAllExperts().subscribe((res) => {
            this.experts = res.json().experts;
        });

        if(this.databaseService.user){
            this.loggedIn = true;
        }

    }

}
