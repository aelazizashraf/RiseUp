import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-founders',
  templateUrl: './founders.component.html',
  styleUrls: ['./founders.component.css']
})
export class FoundersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
