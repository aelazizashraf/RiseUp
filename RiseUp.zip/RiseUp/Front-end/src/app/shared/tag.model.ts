export class Tag{
    _id?:String;
    tag?:String;
}